<img width="802" height="469" alt="Screenshot 2025-12-09 at 01 29 46" src="https://github.com/user-attachments/assets/02926805-abac-49ec-a57d-0975b021de8b" />
